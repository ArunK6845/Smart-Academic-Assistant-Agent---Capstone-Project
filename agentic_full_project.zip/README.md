# Smart Academic Assistant Agent
Full project structure for Kaggle Agentic Capstone.
Includes src/, assets/, notebook.ipynb, and run_demo.py.
