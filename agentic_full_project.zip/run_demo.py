import sys
sys.path.append("src")

from agents.orchestrator import Orchestrator
from agents.planner import PlannerAgent
from agents.content_agent import ContentAgent
from agents.design_agent import DesignAgent
from agents.scheduler_agent import SchedulerAgent
from agents.analytics_agent import AnalyticsAgent
from memory.storage import MemoryStore
from utils.logger import Logger

brief = {
    "title": "AI Seminar on Autonomous Systems",
    "date": "2025-11-20",
    "desc": "A session on agentic AI and real-world automation."
}

agents = {
    "planner": PlannerAgent(),
    "content": ContentAgent(),
    "design": DesignAgent(),
    "scheduler": SchedulerAgent(),
    "analytics": AnalyticsAgent()
}

memory = MemoryStore("memory.db")
orc = Orchestrator(agents, memory)

Logger.log("Running full agentic workflow...")
results = orc.run_event(brief)
print("RESULTS:", results)
