import sqlite3

class MemoryStore:
    def __init__(self, db_path='memory.db'):
        self.conn = sqlite3.connect(db_path)
        self.create_tables()

    def create_tables(self):
        cur = self.conn.cursor()
        cur.execute('''CREATE TABLE IF NOT EXISTS events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT, date TEXT, description TEXT, created_at TEXT)''')

        cur.execute('''CREATE TABLE IF NOT EXISTS assets(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER, asset_type TEXT, path TEXT, score REAL)''')

        cur.execute('''CREATE TABLE IF NOT EXISTS feedback(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER, rating INTEGER, comments TEXT)''')

        self.conn.commit()

    def add_event(self, title, date, desc):
        cur = self.conn.cursor()
        cur.execute('INSERT INTO events(title,date,description,created_at) VALUES (?,?,?,datetime("now"))',
                    (title,date,desc))
        self.conn.commit()
        return cur.lastrowid

    def add_asset(self, event_id, asset_type, path, score=0.0):
        cur = self.conn.cursor()
        cur.execute('INSERT INTO assets(event_id,asset_type,path,score) VALUES (?,?,?,?)',
                    (event_id,asset_type,path,score))
        self.conn.commit()

    def add_feedback(self, event_id, rating, comments):
        cur = self.conn.cursor()
        cur.execute('INSERT INTO feedback(event_id,rating,comments) VALUES (?,?,?)',
                    (event_id,rating,comments))
        self.conn.commit()
