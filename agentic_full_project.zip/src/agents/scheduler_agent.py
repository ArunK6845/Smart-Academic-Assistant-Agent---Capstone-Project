from tools.social_tool_sim import SocialToolSim
from tools.calendar_tool import CalendarTool

class SchedulerAgent:
    def __init__(self):
        self.social = SocialToolSim()
        self.calendar = CalendarTool()

    def schedule_post(self, caption, asset):
        return self.social.post(caption, asset)

    def schedule_calendar(self, title, date):
        return self.calendar.schedule(title, date)
