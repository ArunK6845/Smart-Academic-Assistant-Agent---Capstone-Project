import random

class AnalyticsAgent:
    def evaluate(self, brief):
        likes = random.randint(20,300)
        reach = random.randint(300,8000)
        score = round((likes + reach/10)/10, 2)
        return {"likes":likes, "reach":reach, "score":score}
