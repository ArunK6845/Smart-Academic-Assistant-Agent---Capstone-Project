class ContentAgent:
    def generate(self, title, desc, date):
        caption = f"Join us for '{title}' on {date}. {desc}"
        return {"title":title, "caption":caption, "description":desc}
