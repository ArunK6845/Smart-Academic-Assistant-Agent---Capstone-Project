from utils.logger import Logger

class Orchestrator:
    def __init__(self, agents, memory):
        self.agents = agents
        self.memory = memory

    def run_event(self, brief):
        Logger.log("Creating plan...")
        plan = self.agents["planner"].make_plan(brief)

        event_id = self.memory.add_event(brief["title"], brief["date"], brief["desc"])
        Logger.log(f"Event created ID: {event_id}")

        results = {}

        for step in plan:
            task = step["task"]
            Logger.log(f"Executing: {task}")

            if task == "generate_content":
                results["content"] = self.agents["content"].generate(
                    brief["title"], brief["desc"], brief["date"]
                )

            if task == "generate_poster":
                poster = self.agents["design"].generate(
                    brief["title"], brief["desc"],
                    f"assets/generated/poster_event_{event_id}.png"
                )
                self.memory.add_asset(event_id, "poster", poster)
                results["poster"] = poster

            if task == "schedule_post":
                results["post"] = self.agents["scheduler"].schedule_post(
                    results["content"]["caption"], results["poster"]
                )

            if task == "schedule_calendar":
                results["calendar"] = self.agents["scheduler"].schedule_calendar(
                    brief["title"], brief["date"]
                )

            if task == "collect_feedback":
                fb = {"rating":4, "comments":"Good session"}
                self.memory.add_feedback(event_id, fb["rating"], fb["comments"])
                results["feedback"] = fb

            if task == "run_analytics":
                results["analytics"] = self.agents["analytics"].evaluate(brief)

        return results
