class PlannerAgent:
    def make_plan(self, brief, memory=None):
        return [
            {"task":"generate_content"},
            {"task":"generate_poster"},
            {"task":"schedule_post"},
            {"task":"schedule_calendar"},
            {"task":"collect_feedback"},
            {"task":"run_analytics"}
        ]
