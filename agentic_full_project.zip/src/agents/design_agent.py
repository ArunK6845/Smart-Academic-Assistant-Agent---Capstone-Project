from tools.design_tool import DesignTool

class DesignAgent:
    def __init__(self):
        self.tool = DesignTool()

    def generate(self, title, desc, outpath):
        return self.tool.create_poster(title, desc, outpath)
