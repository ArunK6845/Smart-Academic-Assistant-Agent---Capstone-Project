class CalendarTool:
    def schedule(self, title, date):
        return {"status":"scheduled", "event":title, "date":date}
