class SocialToolSim:
    def __init__(self):
        self.timeline = []

    def post(self, caption, asset):
        entry = {"status": "posted", "caption": caption, "asset": asset}
        self.timeline.append(entry)
        return entry
