from PIL import Image, ImageDraw
import os

class DesignTool:
    def __init__(self, size=(800,1200)):
        self.size = size

    def create_poster(self, title, desc, output_path='assets/generated/poster.png'):
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        img = Image.new('RGB', self.size, color=(40,40,40))
        draw = ImageDraw.Draw(img)
        draw.text((40,60), title, fill=(255,255,255))
        draw.text((40,200), desc, fill=(200,200,200))
        img.save(output_path)
        return output_path
